import Layout from "../Layout";
import AssetDetail from "../screens/AssetDetail";

export default function AssetDetailPage() {
    return (
        <Layout>
            <AssetDetail />
        </Layout>
    );
}
